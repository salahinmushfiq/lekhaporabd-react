// // Contact.jsx — Tailwind-Styled Form + Social + Footer
// import React from "react";

// const Contact=() => {
//   return (
//     <section id="contact" className="py-16 px-4 bg-gray-900 text-white">
//       <div className="text-center mb-12">
//         <h2 className="text-3xl md:text-4xl font-bold">Get in Touch</h2>
//         <p className="text-yellow-400 text-lg mt-2">We'd Love to Hear from You</p>
//       </div>

//       <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
//         <form className="space-y-4">
//           <input
//             type="text"
//             name="name"
//             placeholder="Your Name"
//             className="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
//             required
//           />
//           <input
//             type="email"
//             name="email"
//             placeholder="Your Email"
//             className="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
//             required
//           />
//           <textarea
//             name="message"
//             placeholder="Your Message"
//             rows="5"
//             className="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
//             required
//           ></textarea>
//           <button
//             type="submit"
//             className="w-full bg-yellow-400 text-black font-semibold py-2 px-4 rounded hover:bg-yellow-500 flex justify-center items-center gap-2"
//           >
//             <i className="fas fa-paper-plane"></i> Send Message
//           </button>
//         </form>

//         <div className="flex flex-col justify-center items-center space-y-4">
//           <p className="text-lg">Connect with us on:</p>
//           <div className="flex space-x-4 text-2xl">
//             <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:text-yellow-400">
//               <i className="fab fa-facebook-f"></i>
//             </a>
//             <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="hover:text-yellow-400">
//               <i className="fab fa-youtube"></i>
//             </a>
//             <a href="mailto:someone@example.com" className="hover:text-yellow-400">
//               <i className="fas fa-envelope"></i>
//             </a>
//           </div>
//         </div>
//       </div>

//       <footer className="mt-16 text-center text-gray-400 text-sm">
//         &copy; {new Date().getFullYear()} Lekhaporabd. All rights reserved.
//       </footer>
//     </section>
//   );
// }
// export default Contact

// Contact.jsx — Tailwind-Styled Form + Social + Footer
import React from "react";
import '@fortawesome/fontawesome-free/css/all.min.css';

const Contact=() => {
  return (
    <section id="contact" className="py-16 px-4 bg-gray-900 text-white">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold">Get in Touch</h2>
        <p className="text-yellow-400 text-lg mt-2">We'd Love to Hear from You</p>
      </div>

      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
        <form className="space-y-4">
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            className="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Your Email"
            className="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
            required
          />
          <textarea
            name="message"
            placeholder="Your Message"
            rows="5"
            className="w-full px-4 py-2 rounded bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
            required
          ></textarea>
          <button
            type="submit"
            className="w-full bg-yellow-400 text-black font-semibold py-2 px-4 rounded hover:bg-yellow-500 flex justify-center items-center gap-2"
          >
            <i className="fas fa-paper-plane"></i> Send Message
          </button>
        </form>

        <div className="flex flex-col justify-center items-center space-y-4">
          <p className="text-lg">Connect with us on:</p>
          <div className="flex space-x-4 text-2xl">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:text-yellow-400">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="hover:text-yellow-400">
              <i className="fab fa-youtube"></i>
            </a>
            <a href="mailto:someone@example.com" className="hover:text-yellow-400">
              <i className="fas fa-envelope"></i>
            </a>
          </div>
        </div>
      </div>

      <footer className="mt-16 text-center text-gray-400 text-sm">
        &copy; {new Date().getFullYear()} Lekhaporabd. All rights reserved.
      </footer>
    </section>
  );
}
export default Contact