// Navbar.jsx with Tailwind and responsive drawer
import React, { useState } from "react";
export default function Navbar() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = () => setDrawerOpen(!drawerOpen);

  return (
    <header className="bg-gray-900 text-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="text-xl font-bold">Lekhaporabd</div>
        <div className="md:hidden" onClick={toggleDrawer}>
          <div className="space-y-1 cursor-pointer">
            <span className="block w-6 h-0.5 bg-white"></span>
            <span className="block w-6 h-0.5 bg-white"></span>
            <span className="block w-6 h-0.5 bg-white"></span>
          </div>
        </div>
        <nav className="hidden md:block">
          <ul className="flex space-x-6">
            <li><a href="#" className="hover:text-yellow-400">Home</a></li>
            <li><a href="#categories" className="hover:text-yellow-400">Playlists</a></li>
            <li><a href="#profiles" className="hover:text-yellow-400">Our Team</a></li>
            <li><a href="#" className="hover:text-yellow-400">About</a></li>
            <li><a href="#contact" className="hover:text-yellow-400">Contact</a></li>
          </ul>
        </nav>
      </div>

      {drawerOpen && (
        <div className="md:hidden bg-gray-800 px-4 py-3 space-y-2">
          <a href="#" className="block text-white hover:text-yellow-400">Home</a>
          <a href="#categories" className="block text-white hover:text-yellow-400">Playlists</a>
          <a href="#profiles" className="block text-white hover:text-yellow-400">Our Team</a>
          <a href="#" className="block text-white hover:text-yellow-400">About</a>
          <a href="#contact" className="block text-white hover:text-yellow-400">Contact</a>
        </div>
      )}
    </header>
  );
}
