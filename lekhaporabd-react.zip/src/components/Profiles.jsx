// Profiles.jsx — Realistic dummy team cards for an educational site
import React from "react";

const teamMembers = [
  {
    name: "Ayesha Rahman",
    title: "Founder & Lead Educator",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    description: "A passionate educator with 10+ years of experience in secondary education and digital learning innovation."
  },
  {
    name: "Mahmud Hossain",
    title: "Curriculum Developer",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    description: "Designs student-friendly academic content aligned with national curriculum standards and learning goals."
  },
  {
    name: "Nadia Islam",
    title: "Video Editor",
    image: "https://randomuser.me/api/portraits/women/68.jpg",
    description: "Transforms lessons into engaging video tutorials with visuals that simplify complex concepts."
  },
  {
    name: "Tanvir Ahmed",
    title: "UI/UX Designer",
    image: "https://randomuser.me/api/portraits/men/61.jpg",
    description: "Crafts intuitive and accessible user interfaces to enhance the online learning experience."
  },
  {
    name: "Farhana Kabir",
    title: "Science Instructor",
    image: "https://randomuser.me/api/portraits/women/21.jpg",
    description: "Specialist in secondary science education with a knack for simplifying physics and chemistry topics."
  },
  {
    name: "Rafiq Hasan",
    title: "Math Instructor",
    image: "https://randomuser.me/api/portraits/men/47.jpg",
    description: "Dedicated to helping students master algebra, geometry, and real-life problem-solving skills."
  }
];

export default function Profiles() {
  return (
    <section id="profiles" className="py-16 bg-white text-gray-900">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold">Our Team</h2>
        <p className="text-yellow-500 text-lg">Meet The People Behind Lekhaporabd</p>
      </div>
      <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 px-4">
        {teamMembers.map((member, i) => (
          <div key={i} className="bg-gray-50 rounded-lg shadow-md overflow-hidden text-center p-6">
            <img src={member.image} alt={member.name} className="w-24 h-24 rounded-full mx-auto mb-4 object-cover" />
            <h3 className="text-lg font-bold">{member.name}</h3>
            <p className="text-sm text-yellow-600 font-medium">{member.title}</p>
            <p className="text-sm mt-2 text-gray-700">{member.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
