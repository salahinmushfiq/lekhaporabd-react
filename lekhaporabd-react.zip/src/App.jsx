import React from "react";
import Navbar from "./components/Navbar";
import CarouselBanner from "./components/CarouselBanner";
import Categories from "./components/Categories";
import Profiles from "./components/Profiles";
import Contact from "./components/Contact";
import PromoImages from "./components/PromoImages";

export default function App() {
  return (
    <div className="main bg-gray-50 text-gray-900">
      {/* Navigation */}
      <Navbar />

      {/* Centered Hero Section with Sidebars */}
      <section className="max-w-full mx-auto py-8 px-8 ">
        <div className="grid grid-cols-1 md:grid-cols-[200px_1fr_200px] gap-4 items-stretch">
          {/* Left Sidebar */}
          <div className="hidden md:block">
            <PromoImages />
          </div>

          {/* Center Carousel */}
          <div>
            <CarouselBanner />
          </div>

          {/* Right Sidebar */}
          <div className="hidden md:block">
            <PromoImages />
          </div>
        </div>
      </section>

      {/* Categorized Playlist Section */}
      <section className="py-10 px-4">
        <div className="max-w-7xl mx-auto">
          <Categories />
        </div>
      </section>
      
      {/* Team Section */}
      <section className="bg-gray-100 py-10 px-4">
        <div className="max-w-7xl mx-auto">
          <Profiles />
        </div>
      </section>

<section className="bg-gray-50 py-12">
  <div className="max-w-3xl mx-auto text-center">
    <h2 className="text-2xl font-bold mb-6">What Students Say</h2>
    <div className="bg-white shadow rounded p-6">
      <p className="italic text-gray-600">“This site helped me prepare for SSC better than any coaching center.”</p>
      <p className="mt-4 font-bold text-yellow-500">— Rafiq, Class 10</p>
    </div>
  </div>
</section>
<section className="py-12 bg-white text-center">
  <div className="max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6">
    <div>
      <p className="text-3xl font-bold text-yellow-500">500+</p>
      <p className="text-gray-700">Videos</p>
    </div>
    <div>
      <p className="text-3xl font-bold text-yellow-500">20+</p>
      <p className="text-gray-700">Subjects</p>
    </div>
    <div>
      <p className="text-3xl font-bold text-yellow-500">100K+</p>
      <p className="text-gray-700">Views</p>
    </div>
    <div>
      <p className="text-3xl font-bold text-yellow-500">10+</p>
      <p className="text-gray-700">Educators</p>
    </div>
  </div>
</section>
      {/* Contact Section + Footer */}
      <section className="bg-gray-900 text-white py-10 px-4">
        <footer className="bg-gray-900 text-gray-300 py-10 mt-10">
  <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 px-4">
    <div>
      <h4 className="text-yellow-400 text-lg font-bold mb-2">About</h4>
      <p className="text-sm">Empowering students with quality academic tutorials.</p>
    </div>
    <div>
      <h4 className="text-yellow-400 text-lg font-bold mb-2">Quick Links</h4>
      <ul className="text-sm space-y-1">
        <li><a href="#categories" className="hover:text-white">Categories</a></li>
        <li><a href="#profiles" className="hover:text-white">Team</a></li>
        <li><a href="#contact" className="hover:text-white">Contact</a></li>
      </ul>
    </div>
    <div>
      <h4 className="text-yellow-400 text-lg font-bold mb-2">Follow Us</h4>
      <div className="flex gap-3 text-xl">
        <i className="fab fa-facebook hover:text-white"></i>
        <i className="fab fa-youtube hover:text-white"></i>
        <i className="fab fa-twitter hover:text-white"></i>
      </div>
    </div>
  </div>
</footer>

      </section>
    </div>
  );
}
